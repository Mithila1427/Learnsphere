import { useState } from 'react';
import { MessageCircle } from 'lucide-react';

interface LoginPageProps {
  onLogin: (userType: 'student' | 'teacher') => void;
  onNavigateToRegister: () => void;
}

export function LoginPage({ onLogin, onNavigateToRegister }: LoginPageProps) {
  const [userType, setUserType] = useState<'student' | 'teacher'>('student');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(userType);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-200 via-pink-200 to-purple-300 relative overflow-hidden">
      {/* Background decorative circles */}
      <div className="absolute top-20 left-20 w-40 h-40 bg-white/30 rounded-full blur-2xl"></div>
      <div className="absolute bottom-32 right-32 w-60 h-60 bg-white/20 rounded-full blur-3xl"></div>
      
      <div className="bg-white rounded-3xl shadow-2xl p-12 w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <h1 className="text-4xl mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent" style={{ fontWeight: 700 }}>
            LearnSphere
          </h1>
          <p className="text-gray-600 text-sm">
            Personalized AI Tutoring Enhanced by Human Guidance
          </p>
        </div>

        {/* User Type Toggle */}
        <div className="flex gap-2 mb-8">
          <button
            type="button"
            onClick={() => setUserType('student')}
            className={`flex-1 py-3 rounded-xl transition-all duration-300 ${
              userType === 'student'
                ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Student
          </button>
          <button
            type="button"
            onClick={() => setUserType('teacher')}
            className={`flex-1 py-3 rounded-xl transition-all duration-300 ${
              userType === 'teacher'
                ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Teacher
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-5 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
            required
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-5 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
            required
          />

          <button
            type="submit"
            className="w-full py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl hover:shadow-lg transition-all duration-300 transform hover:scale-105"
          >
            Sign In
          </button>
        </form>

        <p className="text-center mt-6 text-gray-600 text-sm">
          Don't have an account?{' '}
          <button
            onClick={onNavigateToRegister}
            className="text-blue-600 hover:underline"
          >
            Register here
          </button>
        </p>
      </div>
    </div>
  );
}
