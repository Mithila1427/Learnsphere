import { useState } from 'react';
import { LoginPage } from '@/app/components/LoginPage';
import { RegisterPage } from '@/app/components/RegisterPage';
import { StudentDashboard } from '@/app/components/StudentDashboard';
import { TeacherDashboard } from '@/app/components/TeacherDashboard';

type Page = 'login' | 'register' | 'student-dashboard' | 'teacher-dashboard';
type UserType = 'student' | 'teacher' | null;

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [userType, setUserType] = useState<UserType>(null);

  const handleLogin = (type: 'student' | 'teacher') => {
    setUserType(type);
    if (type === 'student') {
      setCurrentPage('student-dashboard');
    } else {
      setCurrentPage('teacher-dashboard');
    }
  };

  const handleRegister = (type: 'student' | 'teacher') => {
    setUserType(type);
    if (type === 'student') {
      setCurrentPage('student-dashboard');
    } else {
      setCurrentPage('teacher-dashboard');
    }
  };

  const handleLogout = () => {
    setUserType(null);
    setCurrentPage('login');
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'login':
        return (
          <LoginPage
            onLogin={handleLogin}
            onNavigateToRegister={() => setCurrentPage('register')}
          />
        );
      
      case 'register':
        return (
          <RegisterPage
            onRegister={handleRegister}
            onNavigateToLogin={() => setCurrentPage('login')}
          />
        );
      
      case 'student-dashboard':
        return <StudentDashboard onLogout={handleLogout} />;
      
      case 'teacher-dashboard':
        return <TeacherDashboard onLogout={handleLogout} />;
      
      default:
        return (
          <LoginPage
            onLogin={handleLogin}
            onNavigateToRegister={() => setCurrentPage('register')}
          />
        );
    }
  };

  return (
    <div className="size-full">
      {renderPage()}
    </div>
  );
}
